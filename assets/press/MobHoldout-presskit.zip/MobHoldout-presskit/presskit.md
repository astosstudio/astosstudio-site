# Mob Holdout – Press Kit

**Hold your street. Stop the mob.**

Mob Holdout is a fast, neon-soaked mafia defense game for iPhone and Android by AstosStudio. Man the turret behind your wall, build a glowing 3D city, raid rival estates and lead your family.

- Full title: **Mob Holdout: Mafia Defense**
- Developer and publisher: **AstosStudio** (the Netherlands)
- Platforms: **iOS (App Store)** and **Android (Google Play)**
- Release: **Coming soon**
- Price: **Free to play**, with optional in-app purchases and optional rewarded ads
- Website: https://www.astosstudio.com
- Press contact: support@astosstudio.com

A one-page fact sheet is in `factsheet.md`.

---

## Description

### One line
Defend your street, build your city, raid rivals and lead your mafia family.

### Short (about 50 words)
The mob is coming for your street, and you are the last line of defense. Mob Holdout is a fast, neon-soaked defense game: man the turret behind your wall, pick the right upgrades, and stop wave after wave of gangsters, armored trucks and mafia bosses. Between fights, build your own 3D city and raid rival estates.

### Long
The mob is coming for your street. You are the last line of defense.

Mob Holdout is a fast, neon-soaked defense game. Man the turret behind your wall, pick the right upgrades and stop wave after wave of gangsters, armored trucks and mafia bosses before they break through.

Your estate is your home base: a glowing 3D city that grows with you. Upgrade your mansion, vault, towers and more, and collect income while you are away. When you are ready to go on the attack, pick your squad, break through the gate of a rival estate and take the loot. Climb the divisions, earn trophies and defend your own estate against other players.

Along the way you recruit eight Capos, each with a unique super attack, perks and mastery levels. Found or join a family to chat, help each other, research bonuses together and take on the weekly Family boss.

There is no energy system. Everything can be earned by playing; optional purchases and rewarded ads help you progress faster and are never required.

---

## Key features

- **Hold the line.** One turret, one wall, one street. Dozens of upgrades to choose from mid-fight (chain lightning, ricochet bullets, drone support, explosive rounds, mortars and more) that combine into powerful evolutions.
- **Build your city.** Your home screen is your own 3D city at night. Upgrade your mansion, vault, towers and more, and collect income while you are away.
- **Raid rival estates.** Pick your squad, break through the gate and take the loot. Climb the divisions, earn trophies and defend your own estate against other players.
- **Recruit legendary Capos.** Eight hand-drawn Capos, each with a unique super attack, perks and mastery levels.
- **1,000 missions and Endless mode.** 20 chapters, three stars to earn on every mission, and an Endless mode to see how long you can hold out.
- **Lead your family.** Found or join a family: chat, help each other, research bonuses together and fight the weekly Family boss.
- **Seasons and events.** A 50-tier season pass, a season boss, daily rewards and events.
- **Fair to play.** No energy system. No paid loot boxes. Everything can be earned by playing.
- **14 languages.** English, Spanish, Portuguese, French, German, Danish, Norwegian, Swedish, Polish, Russian, Ukrainian, Simplified Chinese, Japanese and Korean.

---

## Characters

Art for each character is in `characters/` (transparent PNG).

| Character | Role | Super attack |
|---|---|---|
| **Vito** | The Wrecker (Legendary Capo) | *Wrecking Ball*: a huge blow in the middle of the street that stuns everything nearby |
| **Mama Gina** | The Matriarch (Legendary Capo) | *Family Council*: everyone freezes. Even bosses |
| **Lucia** | The Sharpshooter (Epic Capo) | *Deadly Precision*: takes down the toughest enemies in one go |
| **Bruno** | The Mechanic (Epic Capo) | *Steel Wall*: repairs your wall and shields it against all damage |
| **Marco** | The Driver (Epic Capo) | *Ram Raid*: rams his car through the street and knocks every enemy back |
| **Doctor Rossi** | The Doctor (Rare Capo) | *Adrenaline*: your turret fires many times as fast |
| **Sal** | The Accountant (Rare Capo, and your shopkeeper) | *Gold Fever*: every enemy pays out extra coins |
| **Nonna Rosa** | The Cook (Rare Capo) | *Molotov Buffet*: sets the street in front of your wall on fire |
| **Don Corvino** | The rival don | His mob is the one coming for your street |

---

## Fact sheet (short)

| | |
|---|---|
| Genre | Strategy / Action (lane defense, tower defense) |
| Players | Single player, with online raids on other players' estates, families, chat and leaderboards |
| Connection | Online connection required |
| Age ratings | App Store 13+ · PEGI 7 · ESRB Everyone 10+ · USK 12 |
| Business model | Free to play; optional in-app purchases, an optional monthly subscription (Family VIP) and optional rewarded ads. No paid random items |
| Languages | 14 (see above) |
| Account | No sign-up needed; players can optionally link their progress to an e-mail address |

---

## Assets in this kit

| Folder | Contents |
|---|---|
| `icon/` | App icon, 1024 and 512 px, plus a rounded version on a transparent background |
| `logo/` | The Mob Holdout wordmark on a transparent background |
| `keyart/` | Key art with and without the logo (3840 × 1875) and the 1024 × 500 store graphic |
| `screenshots/with-caption/` | Six store screenshots with a headline (1320 × 2868) |
| `screenshots/clean/` | The same six screens without headline or device frame (1320 × 2868) |
| `characters/` | Nine characters as transparent PNG (1200 × 1488) |

The six screenshots: the city (home screen), a battle, choosing an upgrade, a raid target, the Capos and the mission map.

A trailer and gameplay clips are not available yet.

### Using these assets
You may use everything in this kit for editorial coverage of Mob Holdout: articles, reviews, videos, streams and thumbnails. Please do not alter the logo or characters beyond resizing and cropping, and do not use them to suggest an endorsement or partnership. Videos and streams of the game may be monetized.

---

## About AstosStudio

AstosStudio is an independent studio from the Netherlands making games for iPhone and Android. More at https://www.astosstudio.com.

## Contact

- Press and creators: support@astosstudio.com
- Website: https://www.astosstudio.com
- Support: https://www.astosstudio.com/support/

© 2026 AstosStudio
