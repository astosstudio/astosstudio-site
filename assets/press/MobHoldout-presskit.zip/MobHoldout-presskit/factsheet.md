# Mob Holdout – Fact Sheet

| | |
|---|---|
| **Title** | Mob Holdout: Mafia Defense |
| **Tagline** | Hold your street. Stop the mob. |
| **Developer / publisher** | AstosStudio (the Netherlands) |
| **Platforms** | iOS (App Store), Android (Google Play) |
| **Release** | Coming soon |
| **Price** | Free to play |
| **Business model** | Optional in-app purchases, an optional monthly subscription (Family VIP) and optional rewarded ads. No energy system, no paid random items |
| **Genre** | Strategy / Action (lane defense, tower defense) |
| **Setting** | A fictional neon mafia city |
| **Modes** | 1,000 missions in 20 chapters, Endless mode, raids on rival estates (PvP), weekly Family boss |
| **Social** | Families with chat, shared research and help requests; leaderboards and divisions |
| **Characters** | 8 collectible Capos, each with a super attack |
| **Languages** | English, Spanish, Portuguese, French, German, Danish, Norwegian, Swedish, Polish, Russian, Ukrainian, Simplified Chinese, Japanese, Korean |
| **Age ratings** | App Store 13+ · PEGI 7 · ESRB Everyone 10+ · USK 12 |
| **Connection** | Online connection required |
| **Account** | Created automatically; no sign-up needed |
| **Website** | https://www.astosstudio.com |
| **Privacy policy** | https://www.astosstudio.com/privacy/ |
| **Press contact** | support@astosstudio.com |

**In one line:** Defend your street, build your city, raid rivals and lead your mafia family.

**In one paragraph:** The mob is coming for your street, and you are the last line of defense. Mob Holdout is a fast, neon-soaked defense game: man the turret behind your wall, pick the right upgrades, and stop wave after wave of gangsters, armored trucks and mafia bosses. Between fights, build your own 3D city, raid rival estates, recruit Capos and lead your family.

© 2026 AstosStudio
